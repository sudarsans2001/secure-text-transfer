#include <cstdlib>
#include <iostream>

using namespace std;

class Instruction
{
	public:
		string operation;
		string subject;
		string object;
		int value;
};